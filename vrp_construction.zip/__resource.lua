dependency 'vrp'


server_scripts {
	'@vrp/lib/utils.lua',
	'server.lua'
}
--[[
client_script {
	'@vrp/lib/utils.lua'
}]]